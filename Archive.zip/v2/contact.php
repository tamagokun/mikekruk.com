<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk - Contact</title>
	<link rel="stylesheet" href="master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/lavalamp.js"></script>
	<!-- Optional -->
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript" src="js/iepngfix.js"></script>
	
	<!--[if IE 6]>
		<script type="text/javascript" src="js/jquery.ifixpng.js"></script>
	<![endif]-->
	<script type="text/javascript" src="js/mk-include.js"></script>
	
</head>
<body>
<?php
	include 'includes/top.php';
	include 'includes/global.php';
?>
<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<div class="mid">	
				<h3>contact me</h3>
			
				<div id="leavecomment">
					<?php
						if(isset($_POST['submit'])){
							if( !empty($_POST['mname']) && !empty($_POST['mcomment']) ){
								//send me an email!
								mail('tamagokun@gmail.com',"MIKEKRUK.com contact message " . $_POST['mname'],$_POST['memail'] . "\r\n" . $_POST['mcomment']);
								//tell user that message was sent
								?>
								<strong>message was sent to mike.</strong>
							<?php
							}
						}else{
							//display form
					?>
				  <form method="post" action="contact.php">
					<div class="form_element">
						<p>name</p>
						<input class="text" type="text" size="20" name="mname" />
					</div>
					<div class="form_element">
						<p>e mail</p>
						<input class="text" type="text" size="20" name="memail" />
					</div>
					<div class="form_element">
						<p>comments</p>
						<textarea name="mcomment" rows="1" cols="1"></textarea>
					</div>
					<input type="submit" value="send" name="submit" />
				  </form>
					<?php
						}
					?>
				</div>
					<br />

			</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<a href="http://ripeworks.com" target="_blank">ripeworks</a><br />
			<a href="http://del.icio.us/tamagokun" target="_blank">del.icio.us</a><br />
			<a href="http://mikeirl.tumblr.com" target="_blank">tumblr</a><br />
			<br /><br />
			<a href="http://mikekruk.com/rss/feed.xml"><img src="assets/rss.png" alt="rss feed"/></a>
			
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'includes/bottom.php';
?>