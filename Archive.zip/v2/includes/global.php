<?php
		mysql_connect('127.0.0.1','root','bananaphone');
		mysql_select_db('mkruk_archive');
	
	function createDate($month, $day){
		//create the date image
		$dmonth = strtoupper($month);
		$dday = $day;

		$im = @imagecreatefrompng('assets/calendar-trans.png')
			or die("error");
		imagealphablending($im, true);
		imagesavealpha($im, true);
		$text_color = imagecolorallocate($im, 247, 238, 237);
		imagettftext( $im, 8, -1, 14, 11, $text_color, 'assets/Arial.ttf', $dmonth);
		$day_color = imagecolorallocate($im, 58, 58, 58);
		imagettftext( $im, 20, -1, 10, 34, $day_color, 'assets/Arial.ttf', $dday);
		imagepng($im, "assets/date/" . $dmonth . "-" . $dday . ".png");
	}
?>