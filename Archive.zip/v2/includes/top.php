<div id="top-wrapper">
	<div id="nav">
		<h1><a href="index.php">Mike Kruk.</a></h1>
		<ul class="lavalamp">
			<li><a href="blog.php">blog</a></li>
			<li><a href="photos.php">photos</a></li>
			<li><a href="contact.php">contact</a></li>
		</ul>
		<br class="clear" />
	
		<p>Blogging about life, the web, programming, and being a dad</p>
		</p>
	</div>
</div>