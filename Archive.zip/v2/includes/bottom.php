<div id="bottom">
	<p>
		<a href="http://validator.w3.org/check?uri=referer" target="_blank"><img src="assets/xhtml.png" alt="XHTML 1.0 Transitional" /></a>&nbsp;
			<a href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fmikekruk.com%2Fmaster.css" target="_blank" ><img src="assets/css.png" alt="CSS 2.0" /></a>&nbsp;
				<a href="http://mikekruk.com/rss/feed.xml"><img src="assets/rss_valid.png" alt="RSS 2.0" /></a><br />
		<a href="/v1/">v1</a>&nbsp;|&nbsp;&copy;2008 Mike Kruk.
	</p>
</div>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-4214672-1";
urchinTracker();
</script>
</body>
</html>