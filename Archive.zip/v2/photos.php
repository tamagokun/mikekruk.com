<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk - Photos</title>
	<link rel="stylesheet" href="master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/lavalamp.js"></script>
	<!-- Optional -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!-- required -->
	<script type="text/javascript" src="js/jquery.dimensions.js"></script>
	<!-- optional -->
	<script type="text/javascript" src="js/jquery.shadow.js"></script>
	<script type="text/javascript" src="js/jquery.ifixpng.js"></script>
	<script type="text/javascript" src="js/iepngfix.js"></script>

	<script type="text/javascript" src="js/jquery.fancyzoom-packed.js"></script>
	<script type="text/javascript">
		$(function(){
			$.fn.fancyzoom.defaultsOptions.imgDir='assets/fancyzoom/';
			$('#photostream a').fancyzoom({Speed:0,showoverlay:false});
			
			

		});
	</script>
	<script type="text/javascript" src="js/mk-include.js"></script>
</head>
<body>
<?php
	include 'includes/top.php';
	include 'includes/global.php';

	if(isset($_GET['al'])){
		if(is_numeric($_GET['al'])){
			$album = $_GET['al'];
		}else{
			die("Album ID is not a number! What are you doing?!");
		}
	}else{
		$album = 1;
	}
	
	if(isset($_GET['pid'])){
		if(is_numeric($_GET['pid'])){
			$id = $_GET['pid'];
		}else{
			die("Photo ID is not a number! What are you doing?!");
		}
	}else{
		$id = 0;
	}
?>
<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<div class="mid">	
				<?php
					//get album data
					$query2 = mysql_query("SELECT * FROM `album` WHERE `id`=" . $album . "");
					if( $query2 ){
						$this_album = mysql_fetch_array($query2);
					}
					//grab flickr album
					$get_obg = file_get_contents($this_album['feed']);
					$album_obj = unserialize($get_obg);
					//echo '<pre>';
					//	print_r($album_obj);
					//echo '</pre>';

					$max = count($album_obj['items']);
					
					//get album name
					$query = mysql_query("SELECT * FROM `album` WHERE `id` = " . $album . "");
					if( $query ) {
						$album_name = mysql_fetch_array($query);
						echo '<h2>' . $album_name['name'] . '</h2>';
						echo '<h3>' . $max . ' pictures</h3>';
					}
					
					echo '<ul id="photostream">';
					foreach( $album_obj['items'] as $photo){
						echo '<li><a href="' . $photo['l_url'] . '"><img alt="' . $photo['description_raw'] . '" class="photo" src="' . $photo['t_url'] . '" /></a></li>';
					}
					echo '</ul>';
					/*echo '<img class="photo" src="'. $album_obj['items'][$id]['m_url'] .'" />';
					echo '<p>';
					echo '<span class="num">' . ($id + 1) . '</span> of <span class="num">' . $max . '</span>';
					echo ' | '. $album_obj['items'][$id]['description_raw'] . '<br />';
					echo '</p>';
					if($id > 0){
						//show previous
						echo '<a href="photos.php?al=' . $album . '&pid=' . ($id - 1) . '">';
						echo '<img border="0" src="assets/photo-prev.gif" alt="previous" /></a>&nbsp;&nbsp;';
					}
					if($id + 1 < $max){
						//show next
						echo '<a href="photos.php?al=' . $album . '&pid=' . ($id + 1) . '">';
						echo '<img border="0" src="assets/photo-next.gif" alt="next" /></a>';
					}
					*/

				?>
				<br class="clear" />

			</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<ul id="album">
				<?php
				//fetch the photo albums
				$query = mysql_query("SELECT * FROM `album` ORDER BY `id` DESC");
				if( $query ) {
					while($albums = mysql_fetch_array($query)){
						//display stuff
						if($albums['id'] == $album){
						?>
						<li class="album_on"><a href="photos.php?al=<?php echo($albums['id']); ?>"><?php echo($albums['name']); ?></a></li>
						<?php
						}else{
						?>
						<li><a href="photos.php?al=<?php echo($albums['id']); ?>"><?php echo($albums['name']); ?></a></li>
						<?php
						}
					}
				}
				?>
			</ul>
			
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'includes/bottom.php';
?>