<?php

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk. Prodigious happens here.</title>
	<link rel="stylesheet" href="master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/lavalamp.js"></script>
	<!-- Optional -->
	<script type="text/javascript" src="js/easing.js"></script>
	
	<!--[if IE 6]>
		<script type="text/javascript" src="js/jquery.ifixpng.js"></script>
		<script type="text/javascript">
			$.ifixpng('../assets/fancyzoom/blank.gif');
			$('img[@src$=.png]').ifixpng();
		</script>
	<![endif]-->
	<script type="text/javascript" src="js/iepngfix.js"></script>
	<script type="text/javascript" src="js/mk-include.js"></script>
	<meta name="description" content="Mike Kruk. Pushing the envelope to bring you beautiful, semantic, and successful web solutions. A blog about web development. A portfolio. A photo gallery." />
	<meta name="keywords" content="mike,kruk,mike kruk,blog,portfolio,rss,design,css,html,xhtml,php,ajax,java,javascript,js,web,2.0,develop,business,sql,tamago,tamagokun,egg,flash,action,script,as3" />
	<meta name="verify-v1" content="h2lSl5rXAwrhCv1s3HhPLSQCK7BnmRCg5QsClJeq/6A=" />
	
</head>
<body>
<?php
	include 'includes/top.php';
	include 'includes/global.php';
?>
<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<div class="mid">	
				<?php
					//fetch recent news
					$fetch = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT 3");
					if( $fetch ){
						while($news = mysql_fetch_array($fetch)){
							//date
							$month = date('M',strtotime($news['date']));
							$day = date('d',strtotime($news['date']));
							createDate($month, $day );
							//display the rest of the stuff
							echo("<img class='date' alt='Date' src='assets/date/" . strtoupper($month) . "-" . $day . ".png' />");
							//title
							echo("<h2><a href='view_blog.php?bid=" . $news['id'] . "'>" . stripslashes($news['title']) . "</a></h2>");
							//time
							echo("<h3>" . date('h:i a',strtotime($news['date'])) . "</h3>");
							//excerpt
							$excerpt = strip_tags($news['entry'], '<p>');
							echo( substr_replace(stripslashes($excerpt), '...', 185) );
							echo("<a href='view_blog.php?bid=" . $news['id'] . "'>read more</a></p>");
						}
					}
				?>
				<br class="clear" />

			</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<a href="http://ripeworks.com" target="_blank">ripeworks</a><br />
			<a href="http://del.icio.us/tamagokun" target="_blank">del.icio.us</a><br />
			<a href="http://mikeirl.tumblr.com" target="_blank">tumblr</a><br />
			<br /><br />
			<a href="http://mikekruk.com/rss/feed.xml"><img src="assets/rss.png" alt="rss feed"/></a>
			
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'includes/bottom.php';
?>