<?php
	mysql_connect('db1296.perfora.net','dbo230753787','RFGGRbyv');
	mysql_select_db('db230753787');
	
	//fetch recent news
	$fetch = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC");
	if( $fetch ){
		$count = 1;
		while($news = mysql_fetch_array($fetch)){
		echo("<a href='asfunction:blogClick,http://mikekruk.com/view_blog.php?bid=" . $news['id'] . "'><span style='color:#527184;'>" . date('M d, Y',strtotime($news['date'])) . "&nbsp;</span>&nbsp;<b>" . stripslashes($news['title']) . "</b></a>");
		if( $count == 1){
			echo("<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . substr_replace(stripslashes($news['entry']), '...', 45) . "<br />");
		}else{
			echo("<br />");
		}
		$count++;
		}
	}
?>