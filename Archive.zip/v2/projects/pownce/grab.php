<?php

ini_set('error_reporting', 8191);
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
ini_set('memory_limit', '16M');
set_time_limit(100);

include('json.php');


$json = new Services_JSON();


/*
OUTPUT ALL CONTENT OF DECODED JSON
echo "<pre>";
print_r($value);
echo "</pre>";
*/

/*
INSTANTIATING VARIABLE FROM ROOT OUTPUT
echo "<pre>";
echo "<b>LOOK HERE IF YOU GET UNDEFINED ERRORS</b><br>";
echo 'user name for $value->users[0]->user[0]->username is: '.$value->users[0]->user[0]->username;
echo "</pre>";
*/




function userInfo($user){
  global $json;
  $input = file_get_contents('http://api.pownce.com/1.0/users/'.$user.'/friends.json');
  $input = $json->decode($input);

  $users = array();

  foreach($input->users as $var => $val){
  
  /* OLD DUMPS
    echo "<pre>";
    $x = var_export($val->user, true);
    print_r($x);
    echo "</pre>";
  */
  
    /*
    echo "<pre>";
    echo "<b>USER:</b><br>";
    */
    
    foreach($val->user as $var1 => $val1){
    
      foreach($val1 as $var2 => $val2){
        
        if($var2 == 'username'){
          $username = $val2;
          $users[$username] = array();
        }
        
        if(is_array($val2)){
          // echo "---ARRAY BEGINS---<br>";
          foreach($val2 as $var3 => $val3){
            if(is_object($val3)){
              foreach($val3 as $var4 => $val4){
                $users[$username][$var4] = $val4;
              }
            }else{
              $users[$username][$var3] = $val3;
            }
          }
          // echo "---ARRAY ENDS---<br>";
        }else{
          $users[$username][$var2] = $val2;
        }
        
      }
      
    }
    
    //echo "</pre>";
    
  }
  
  return $users;
  
}

?>
