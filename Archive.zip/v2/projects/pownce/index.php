<?php
	
	include 'grab.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>POWNCE - Friend Suggester</title>
<link rel="stylesheet" href="reset.css" media="all" type="text/css" />
<link rel="stylesheet" href="main.css" media="all" type="text/css" />

<link rel="stylesheet" href="h-yellow.css" media="all" type="text/css" />
<link rel="stylesheet" href="n-brown.css" media="all" type="text/css" />

<style type="text/css" media="all">

    body {
        background-position: center top;
        background-color: #382920;
        background-image: url(/img/theme-background/assam.gif);
        background-repeat: repeat;    
    }
    
    a:link,
    a:visited,
    ul.notes li.ad-note .note-contents a em,
    .ad-example a, a:hover,
    a:active,
    a.add-new {
    	color: #FFFD52;
    }
    
</style>
</head>
<body>
<div id="side-1">
<h3>Suggested Friends</h3>
<ul class="friends">
<?php
	
	if(isset($_POST['submit'])){
	
	
		//pull friends of the user
		if( $main_user = userInfo($_POST['namebox']) ){
			$the_user = $_POST['namebox'];
		
			//if you have more than one friend....
			if(count($main_user) > 1){
			
				//dump each friend's friends into array
				$friend_count = 0;
				foreach($main_user as $key => $value){
					$friend[$friend_count] = userInfo($key);
					$friend_count += 1;
				}
			
				//compare each friend's friends and put matches into array SUGGEST
				$ubound = count($friend) - 1;
				for($z = 0; $z < $ubound; $z++){
					for($k = ($z + 1); $k <= $ubound; $k++){
						$sug = array_intersect($friend[$z], $friend[$k]);
						$suggest[] = $sug;
					}
				}
				
				//get rid of any multiple users
				$new_suggest = array_unique($suggest);
				
				//remove friends that are already friends of the user, and remove the USER from the array
				foreach($main_user as $key => $value){
					if( array_key_exists($the_user, $new_suggest[0]) ){
						//remove that key!
						unset($new_suggest[0][$the_user]);
					}
					if( array_key_exists($key, $new_suggest[0]) ){
						//remove that key!
						unset($new_suggest[0][$key]);
					}
				}
				
				//display results w/ POWNCE styling
				foreach($new_suggest[0] as $key => $value){
					foreach($value as $var1 => $val1){
						if($var1 == 'username'){
							$this_user = $val1;	
						}
						if($var1 == 'permalink'){
							echo '<li class="vcard"><abbr class="fn" title=""><a class="url" rel="suggested" href="' . $val1 . '">';
						}
						if($var1 == 'smedium_photo_url'){
							echo '<img class="user logo" alt="" src="' . $val1 . '"/>';
							echo $this_user . '</a></abbr></li>';
						}		
					}
				}
				
				
			}else{
				echo("You need more friends!");
			}
		}else{
			echo "invalid userid!";
		}
	
	}else{
		?>
        <form action="index.php" method="post" name="blah">
		enter your user id:<br />
        <input type="text" name="namebox" style="width: 100px; margin-bottom: 10px;" /><br />
		<input type="submit" name="submit" value="Go!" />
		</form>
    <?php
	}
?>
</ul>
</div>
</body>
</html>