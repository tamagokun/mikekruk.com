
            $(document).ready(function(){
				$(function() { $(".lavalamp").lavaLamp({ fx: "backout", speed: 700 })});
                var firstLI = $('#folio li').eq(0);
                var firstOffset = firstLI.offset();
                var clickTriggered = false;
				firstLI.addClass('selected');
                $('#folio li').css({
                    position: 'relative',
                    top: 'auto'
                }).click(function(){
                    $('#folio li').removeClass('selected');

                    var $thisLI = $(this);
                    var $thisUL = $thisLI.parents('ul').eq(0);

					var thisIndex = $('#folio li').index( $(this)[0] );
					var portIndex = $('#folio li').eq(thisIndex).attr("id");
                    var thisOffset = $thisLI.offset();
					var offSet = 128 * thisIndex;
                    var newFirstLI = $('#folio li').eq(0);
                    //cloning
                    if (clickTriggered == false) {
                        clickTriggered = true;
						$thisLI.addClass('selected');
                        var $that = $thisLI.clone(true).prependTo($thisUL).hide();
                        $thisLI.animate({
                            //top: -thisOffset.top + 'px'
                        	top: -offSet + 'px'
						}, "medium", function(){
                            $that.show();
                            $thisLI.remove();
                            // reinitalise the left position
                            $('#folio li').css({
                                top: 'auto'
                            });
							var portDesc = $("#maincontent").children(".mid");
							for( var i=0; i < portDesc.length; i++){
								if( "port"+i == portIndex )
									$( portDesc[i] ).css("display","block");
								else
									$( portDesc[i] ).css("display","none");
							}
                            clickTriggered = false;
                        });
                    }
                });
            });