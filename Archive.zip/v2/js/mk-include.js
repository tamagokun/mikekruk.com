$(document).ready(function(){
	$(function() { 
		$(".lavalamp").lavaLamp({ fx: "backout", speed: 700 });
		$("img[@src$=png],.top, .mid, .bottom, #bottom, #main-thumbs, #relatedcontent").pngfix({ repeatMethod: "crop" });
	});
	


//Growl.NotificationType someKindOfNotification = new Growl.NotificationType("some kind of notification", true);
//Growl.register("Website Name", [someKindOfNotification]);
//Growl.notify(someKindOfNotification, 'Notification from the web', 'this is the description', Growl.Priority.VeryLow, false);
 
	
});