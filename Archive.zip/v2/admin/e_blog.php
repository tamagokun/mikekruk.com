<?php

include_once 'markdown.php';

if(isset($_GET['bid']))
	$edit_blog = $_GET['bid'];
else
	die("no blog to edit?!");
	
	if($rez <> 1){
		die("You are <strong>NOT</strong> the admin! What are you doing?!");
	}
?>

	<?php
		if(isset($_POST['submit'])){
			
			$title = addslashes( $_POST['title'] );
			$entry = Markdown($_POST['blog']);
			$entry = addslashes($entry);
			//update blog
			$query = mysql_query("UPDATE `news` SET `title`='" . $title . "', `entry`='" . $entry . "', `img_type`=" . $_POST['image_type'] . ", `img_path`='" . $_POST['img_path'] . "' WHERE `id`=" . $edit_blog . "");
			if( $query ) {
				echo("SUCCESS!<br />");
			}else{
				echo ("FAILURE!<br />");
			}
		
			
		}
	?>
	<br />
	<?php
		//fetch blog data
		$myBlog = mysql_fetch_array(mysql_query("SELECT * FROM `news` WHERE `id`=" . $edit_blog . ""));
	?>
	<form action="index.php?view=2&bid=<?php echo($edit_blog); ?>" method="post">
<div id="leavecomment">
	<div class="form_element">
		<p>blog title</p>
		<input class="text" type="text" size="40" name="title" value="<?php echo(stripslashes($myBlog['title'])); ?>" />
	</div>
	<div class="form_element">
		<p>image</p>
    <select name="image_type" id="image_type">
    <option value="0"><em>Image Type</em></option>
    <option value="1">Header Image</option>
    <option value="2">Inline Image</option>
    </select>
    <script language="javascript">
		var x = document.getElementById("image_type");
		x.selectedIndex=(<?php echo($myBlog['img_type']);?>);
	</script>
    &nbsp;
    <input type="text" size="30" name="img_path" value="<?php echo($myBlog['img_path']);?>"/>
	</div>
    <?php
		require_once 'markdownify.php';
		$md = new Markdownify;
		$the_blog = $md->parseString(stripslashes($myBlog['entry']));
	?>
	<div class="form_element">
		<p>blog</p>
		<textarea class="blogtext" name="blog" cols="80" rows="10"><?php echo( $the_blog); ?></textarea>
      		<br>
      		<input type="submit" value="Submit" name="submit" />
	</div>
</div>
	</form>