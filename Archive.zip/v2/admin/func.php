<?php

function check_cookie(){
	if(isset($_COOKIE['port_id']) && isset($_COOKIE['port_pass'])){
		$fetch = mysql_query("SELECT * FROM `admin` WHERE UPPER(name)='" . $_COOKIE['port_id'] . "' AND `pass`='" . $_COOKIE['port_pass'] . "'");
			if( $fetch ){
				//YAY! login
				return 1;
			}else{
				return 0;
			}
	}else{
		return 0;
	}
}
?>