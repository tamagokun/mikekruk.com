<html>
<head>
<link rel="stylesheet" type="text/css"  href="../css.css" />
</head>
<body>
<div id="banner">
<a href=#><img src="../images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="homebutton">
<a href="index.php"><img src="../images/home.gif" border="0" alt="home" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu_top.php'; ?>
	<?php
	include 'func.php'; 
	//validate if admin is accessing this page
	$rez = check_cookie();
	
	if($rez <> 1){
		die("You are <strong>NOT</strong> the admin! What are you doing?!");
	}
?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div id="blog-wrap">
		<?php
		if(isset($_POST['submit'])){
			//UPLOAD PHOTO
			unset($imagename);
			if(!isset($_FILES) && isset($HTTP_POST_FILES))
				$_FILES = $HTTP_POST_FILES;
			if(!isset($_FILES['image_file']))
				$error["image_file"] = "An image was not found.";	
			$imagename = basename($_FILES['image_file']['name']);
			//echo $imagename;
			if(empty($imagename))
				$error["imagename"] = "The name of the image was not found.";
			if(empty($error))
			{
				$newimage = "../screens/" . str_replace(" ","_",$imagename);
				//echo $newimage;
				$result = move_uploaded_file($_FILES['image_file']['tmp_name'], $newimage);
				if(empty($result)){
					$error["result"] = "There was an error moving the uploaded file.";
				}else{
					preg_match("'^(.*)\.(gif|jpe?g|png|bmp)$'i", $newimage, $ext);
					switch (strtolower($ext[2])) {
						case 'jpg' :
						case 'jpeg': $src_img  = imagecreatefromjpeg ($newimage);
									break;
						case 'gif' : $src_img  = imagecreatefromgif  ($newimage);
										break;
						case 'png' : $src_img  = imagecreatefrompng  ($newimage);
										break;
						case 'bmp' : $stop = true;
										die("<div class=warning>This image format is <b>not</b> accepted!</div><a href=add_fdss.php>try again</a>");
										break;
						default    : $stop = true;
										die("<div class=warning>This image format is <b>not</b> accepted!</div><a href=add_fdss.php>try again</a>");
										break;
					}
					$origw=imagesx($src_img);
					$origh=imagesy($src_img);
					$max_x = 500;
					$max_y = 2000;
					if( $origw > $max_x || $origh > $max_y){
						if (($max_x/$max_y) < ($origw/$origh)) {
							$dst_img = imagecreatetruecolor($origw/($origw/$max_x), $origh/($origw/$max_x));
						}else {
							$dst_img = imagecreatetruecolor($origw/($origh/$max_y), $origh/($origh/$max_y));
						}	   
						imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0,imagesx($dst_img), imagesy($dst_img), $origw, $origh);
						imageinterlace($dst_img,1);
						imagejpeg($dst_img, $newimage, 100);
					}else{
						$dst_img = imagecreatetruecolor($origw, $origh);
						imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0,imagesx($dst_img), imagesy($dst_img), $origw, $origh);
						imageinterlace($dst_img,1);
						imagejpeg($dst_img, $newimage, 100);
					}
					
					$post = mysql_query("INSERT INTO `fd_screen` SET `file`='" . str_replace(" ","_",$imagename) . "', `date`= now(), `id`=" . $use_id . ", `caption`='" . addslashes($_POST['caption']) . "'");
					if( $post )
						echo("<div class=warning>Screenshot Successfully Added!<br><a href=photogall.php>ok</a></div>");
				}
			}
							
			if(!empty($error)){
				if(is_array($error)){
					while(list($key, $val) = each($error)){
						echo $val;
						echo "<br>\n";
					}
				}
			}
		}
		?>
	<h1>add a Forgotten Destiny screenshot</h1>
	<form action="a_fdss.php" method="post" enctype="multipart/form-data" name="image_upload_form" >
	<table>
	<tr><td><span class="formi">screen shot:&nbsp;</span></td><td><input type="file" size="40" name="image_file" /></td></tr>
	<tr><td><span class="formi">caption:&nbsp;</span></td><td><input type="text" size="40" name="caption" /></td></tr>
    <tr><td></td><td><input type="submit" value="Submit" name="submit" /></td></tr>
	</table>
    </form>
	</div>
	</div>
	
</div>

</body>
</html>