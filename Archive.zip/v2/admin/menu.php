<ul>
<li><a href="index.php?view=1">write</a></li>
<li><a href="index.php">manage</a></li>
<li><a href="index.php?view=3">album</a></li>
<li><a href="#">sign off</a></li>
</ul>