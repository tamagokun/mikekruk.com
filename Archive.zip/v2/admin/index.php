<?php
ob_start();
include 'func.php';

$max_view = 4;

if( isset($_GET['view'])){
	if(is_numeric($_GET['view'])){
		if($_GET['view'] <= $max_view){
			$view = $_GET['view'];
		}
	}
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk</title>
	<link rel="stylesheet" href="../master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="../js/jquery.js"></script>
	
	<!--[if lt IE 7]>
		<script type="text/javascript" src="../js/jquery.ifixpng.js"></script>
		<script type="text/javascript">
			$.ifixpng('../assets/fancyzoom/blank.gif');
			$('img[@src$=.png]').ifixpng();
		</script>
	<![endif]-->
	
</head>
<body>
<?php
	include 'top.php';
	include '../includes/global.php';
?>
<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<div class="mid">	
				<h2>admin control panel</h2>
				<?php
					//check if logged in
					$rez = check_cookie();

					if($rez == 1){
						//get my info
						$me = mysql_fetch_array(mysql_query("SELECT * FROM admin WHERE UPPER(name)='" . $_COOKIE['port_id'] . "' AND pass='" . $_COOKIE['port_pass'] . "'"));
						switch($view) {
							case 1:
								include 'a_blog.php';
								break;
							case 2:
								include 'e_blog.php';
								break;
							case 3:
								include 'a_album.php';
								break;
							case 4:
								
								break;
							default:
								include 'm_blog.php';
						}
					}else{
						include 'login.php';
					}
				?>
				<br class="clear" />

			</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<?php
				if( $rez == 1){
					include 'menu.php';
				}
			?>
			
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'bottom.php';
?>