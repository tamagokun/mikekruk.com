<div id="bottom">
	<p>
		<a href="/v1/">v1</a>&nbsp;|&nbsp;<a href="">privacy policy</a>&nbsp;|&nbsp;
		<a href="">about</a>&nbsp;|&nbsp;&copy;2008 Mike Kruk.
	</p>
</div>
</body>
</html>