<?php
	if($rez <> 1){
		die("You are <strong>NOT</strong> the admin! What are you doing?!");
	}
?>

	<?php
		if(isset($_GET['delete'])){
			$theBlog = $_GET['delete'];
			//delete the comments
			$killcom = mysql_query("DELETE FROM `comment` WHERE `blogid`=" . $theBlog . "");
			//delte the blog
			$kill_blog = mysql_query("DELETE FROM `news` WHERE `id`=" . $theBlog . "");
		}
	?>
	<ul class="admin">
	<?php
		//get blogs
		$fetch = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC");
		if( $fetch ){
			$count = 1;
			while($news = mysql_fetch_array($fetch)){
				?>
				<li>
				<table>
				<tr><td><a href="../view_blog.php?bid=<?php echo($news['id']); ?>"><?php echo($count); ?>&nbsp;<?php echo(stripslashes($news['title'])); ?></a></td><td>
				<a href="index.php?view=2&bid=<?php echo($news['id']); ?>"><img src="edit.png" border="0" alt="edit" /></a></td><td>
				<a href="index.php?delete=<?php echo($news['id']); ?>"><img src="delete.png" border="0" alt="edit" /></a></td>
				</tr>
				</table>
				</li>
				<?php
				$count++;				
			 }
		}
	?>
	</ul>