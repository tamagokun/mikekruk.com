<div id="top-wrapper">
	<div id="nav">
		<h1><a href="index.php">Mike Kruk.</a></h1>
		<ul class="lavalamp">
			<li><a href="blog.php">blog</a></li>
			<li><a href="portfolio.php">portfolio</a></li>
			<li><a href="photos.php">photos</a></li>
			<li><a href="contact.php">contact</a></li>
		</ul>
		<br class="clear" />
	
		<p>welcome to the admin control panel.
		</p>
	</div>
</div>
	<?php
		mysql_connect('db1296.perfora.net','dbo230753787','RFGGRbyv');
		mysql_select_db('db230753787');
		
		include_once 'markdown.php';
	?>