<div id="top-wrapper">
	<div id="nav">
		<h1><a href="../index.php">Mike Kruk.</a></h1>
		<br class="clear" />
	
		<p>pushing the envelope to bring you beautiful, semantic, and
			successful web solutions.
		</p>
	</div>
</div>