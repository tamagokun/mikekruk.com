<?php
		if (isset($_POST['login'])) {
			//check login
			if(empty($_POST['id']) || empty($_POST['pass'])){
				echo("<br /><center><h2>username or password is missing!</h2></center>");
			}else{
				$check = mysql_query("SELECT * FROM `admin` WHERE UPPER(name) = '" . strtoupper($_POST['id']) . "' && `pass`='" . md5($_POST['pass']) . "'");
			
				if(mysql_num_rows($check) == 1){
						//set cookies until browser closes
						setcookie("port_id", $_POST['id'], 0, '/');
						setcookie("port_pass", md5($_POST['pass']), 0, '/');
						echo("<br /><center><div class=sep><center><h1>thank you for logging in</h1><img src='images/hprogress.gif' alt='load' /><br /><br /><a href=index.php>continue</a><br /></center></div></center>");
					ob_end_flush();
				}else{
					//error
					echo("<br /><center><h2>username or password is incorrect!</h2></center>");
				}
			}
		}else{
		?>
		<form method="post" action="index.php">
			<table cellpaddin="2">
			<tr><td><span class="formi">name:&nbsp;</span></td><td><input type="text" size="15" name="id" /></td></tr>
			<tr><td><span class="formi">pass:&nbsp;</span></td><td><input type="password" size="15" name="pass" /></td></tr>
			<tr><td></td><td><input type="submit" name="login" value="Login" /></td></tr>
			</table>
		</form>
		<?php
		}
		?>