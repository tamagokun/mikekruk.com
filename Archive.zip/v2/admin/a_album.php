<?php
	if($rez <> 1){
		die("You are <strong>NOT</strong> the admin! What are you doing?!");
	}
?>
	<?php
		if(isset($_POST['submit'])){
			//post album
			$query = mysql_query("INSERT INTO `album` SET `name`='" . addslashes($_POST['title']) . "', `date`=now(), `feed`='" . $_POST['feed'] . "'");
			if( $query ) {
				echo("SUCCESS!<br />");
			}else{
				echo ("FAILURE!<br />");
			}
		}
	?>
<div id="leavecomment">
	<form action="index.php?view=3" method="post">
	<div class="form_element">
		<p>album name</p>
		<input class="text" type="text" size="40" name="title" />
	</div>
	<div class="form_element">
		<p>Flickr&#174; feed</p>
		<input class="text" type="text" size="40" name="feed" /><br />
		<input type="submit" value="Submit" name="submit">
	</div>
    </form>
</div>