<?php
include("../fckeditor/fckeditor.php") ;
?>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="../css.css" />
</head>
<body>
<div id="banner">
<a href=#><img src="../images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="homebutton">
<a href="index.php"><img src="../images/home.gif" border="0" alt="home" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu_top.php'; ?>
	<?php
	include 'func.php';
	//validate if admin is accessing this page
	$rez = check_cookie();
	
	if($rez <> 1){
		die("You are <strong>NOT</strong> the admin! What are you doing?!");
	}
?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div id="blog-wrap">
	<?php
		if(isset($_POST['FCKeditor1'])){
			$entry = addslashes($_POST['FCKeditor1']);
			$title = addslashes( $_POST['title'] );
			//post blog
			$query = mysql_query("INSERT INTO `fd_news` SET `title`='" . $title . "', `entry`='" . $entry . "', `date`=now()");
			if( $query ) {
				echo("SUCCESS!<br />");
			}else{
				echo ("FAILURE!<br />");
			}
		}
	?>
	<h1>what's new in forgotten destiny?</h1>
	<br />
	<form action="a_fdnews.php" method="post">
	<span class="formi">news title:&nbsp;</span><input type="text" size="40" name="title" /><br />
	<br />
	<?php
	$oFCKeditor = new FCKeditor('FCKeditor1') ;
	$oFCKeditor->BasePath = '/fckeditor/';
	$oFCKeditor->Value = '';
	$oFCKeditor->Height = '500' ;
	$oFCKeditor->Create() ;
	?>
      <br>
      <input type="submit" value="Submit">
    </form>
	</div>
	</div>
	
</div>

</body>
</html>