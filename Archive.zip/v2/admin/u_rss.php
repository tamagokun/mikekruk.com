<?php include 'menu_top.php'; ?>
<?php
include 'func.php';
//validate if admin is accessing this page
$rez = check_cookie();

if($rez <> 1){
	die("You are <strong>NOT</strong> the admin! What are you doing?!");
}

//update RSS
$query = mysql_query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 15");
if( $query ){
	$handle = fopen('../rss/feed.xml', "w");
	fwrite($handle, '<?xml version="1.0" encoding="utf-8"?>');
	fwrite($handle, '<rss version="2.0">');
		fwrite($handle, '<channel>');
			fwrite($handle, '<title>Mike Kruk.</title>');
			fwrite($handle, '<link>http://mikekruk.com</link>');
			fwrite($handle, '<description>My personal blog. Sharing stories, tips, and insight of my world, and the world of the web.</description>');
			fwrite($handle, '<lastBuildDate>' . date("r") . '</lastBuildDate>');
			fwrite($handle, '<language>en-us</language>');
	while( $stories = mysql_fetch_array($query)){
		fwrite($handle, '<item>');
			fwrite($handle, '<title>' . stripslashes($stories['title']) . '</title>');
			fwrite($handle, '<link>http://mikekruk.com/view_blog.php?bid=' . $stories['id'] . '</link>');
			fwrite($handle, '<guid>http://mikekruk.com/view_blog.php?bid=' . $stories['id'] . '</guid>');
			fwrite($handle, '<pubDate>' . date('r', strtotime($stories['date'])) . '</pubDate>');
			fwrite($handle, '<description><![CDATA[ ' . stripslashes($stories['entry']) . ' ]]></description>');
			fwrite($handle, '</item>');
	}
		fwrite($handle, '</channel>');
	fwrite($handle, '</rss>');
	fclose($handle);
}

?>