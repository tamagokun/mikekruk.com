<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk - Blog</title>
	<link rel="stylesheet" href="master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/lavalamp.js"></script>
	<!-- Optional -->
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript" src="js/iepngfix.js"></script>
	<!--[if IE 6]>
		<script type="text/javascript" src="js/jquery.ifixpng.js"></script>
	<![endif]-->
	<script type="text/javascript" src="js/mk-include.js"></script>
</head>
<body>
<?php
	include 'includes/global.php';
	include 'includes/top.php';
?>
<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<div class="mid">	
				<?php
					//fetch recent news
					$fetch = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC");
					if( $fetch ){
						while($news = mysql_fetch_array($fetch)){
							//comments
							//fetch comment count
							$subfetch = mysql_num_rows(mysql_query("SELECT `id` FROM `comment` WHERE `blogid`=" . $news['id'] . ""));
							if( $subfetch == 1 ){
								$comment = 'comment';
							}else{
								$comment = 'comments';
							}
							//date
							$month = date('M',strtotime($news['date']));
							$day = date('d',strtotime($news['date']));
							createDate($month, $day );
							//display the rest of the stuff
							echo("<img class='date' alt='Date' src='assets/date/" . strtoupper($month) . "-" . $day . ".png' />");
							//title
							echo("<h2 id='blog-" . $news['id'] . "'><a href='view_blog.php?bid=" . $news['id'] . "'>" . stripslashes($news['title']) . "</a></h2>");
							//time
							echo("<h3>" . date('h:i a',strtotime($news['date'])) . "&nbsp;&nbsp;&nbsp;");
							echo( $subfetch . "&nbsp;" . $comment . "</h3><div class='clear'></div>");
							//entry
							if($news['img_type'] == 1){
								echo '<p><img src="/v2' . $news['img_path'] . '" alt="" /></p>';
							}
							if($news['img_type'] == 2){
								echo '<img src="/v2' . $news['img_path'] . '" alt="" class="inline" />';
							}
							echo( stripslashes($news['entry']) );
							//echo( "<ul class='important_list'></ul>");
						}
					}
				?>
				<br class="clear" />

			</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<a href="http://ripeworks.com" target="_blank">ripeworks</a><br />
			<a href="http://del.icio.us/tamagokun" target="_blank">del.icio.us</a><br />
			<a href="http://mikeirl.tumblr.com" target="_blank">tumblr</a><br />
			<br /><br />
			<a href="http://mikekruk.com/rss/feed.xml"><img src="assets/rss.png" alt="rss feed"/></a>
			
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'includes/bottom.php';
?>