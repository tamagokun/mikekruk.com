<?php
	include 'includes/global.php';
	
	if(isset($_GET['bid'])){
		if(is_numeric($_GET['bid'])){
			$blogid = $_GET['bid'];
		}else{
			die("ID is not a number. What are you doing?!");
		}
	}else{
		die("ID is missing. What are you doing?!");
	}
	
	//fetch blog
	$fetch = mysql_query("SELECT * FROM `news` WHERE `id`=" . $blogid . "");
	if( $fetch ){
		$news = mysql_fetch_array($fetch);
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk - <?php echo ( stripslashes($news['title']) ); ?></title>
	<link rel="stylesheet" href="master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/lavalamp.js"></script>
	<!-- Optional -->
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript" src="js/iepngfix.js"></script>
	<!--[if IE 6]>
		<script type="text/javascript" src="js/jquery.ifixpng.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="js/mk-include.js"></script>
</head>
<body>
<?php
	include 'includes/top.php';
?>
<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<div class="mid">	
				<?php
				//handle comment posting
				if(isset($_POST['submit'])){
					if($_POST['real_check'] == 'goodboy'){
						if(!empty($_POST['name']) && !empty($_POST['comment'])){
							//do the post
							$name = addslashes($_POST['name']);
							$comment = addslashes($_POST['comment']);
							//handle logged in status for comment type
							if(isset($_COOKIE['port_id']) && isset($_COOKIE['port_pass'])){
								$my_type = 2;
							}else{
								$my_type = 1;
							}
							$query = mysql_query("INSERT INTO `comment` SET `blogid`=" . $blogid . ", `date`=now(), `user`='" . $name . "', `comment`='" . $comment . "', `type`=" . $my_type . "");
						}
					}
				}
					
						//comments
						//fetch comment count
						$subfetch = mysql_num_rows(mysql_query("SELECT `id` FROM `comment` WHERE `blogid`=" . $news['id'] . ""));
						if( $subfetch == 1 ){
							$comment = 'comment';
						}else{
							$comment = 'comments';
						}
						//date
						$month = date('M',strtotime($news['date']));
						$day = date('d',strtotime($news['date']));
						createDate($month, $day );
						//display the rest of the stuff
						echo("<img class='date' alt='Date' src='assets/date/" . strtoupper($month) . "-" . $day . ".png' />");
						echo("<h2 id='blog-" . $news['id'] . "'>" . stripslashes($news['title']) . "</h2>");
						//time
						echo("<h3>" . date('h:i a',strtotime($news['date'])) . "</h3>");
						echo( "<div class='clear'></div>");
						//entry
						if($news['img_type'] == 1){
							echo '<p><img src="/v2' . $news['img_path'] . '" alt="" /></p>';
						}
						if($news['img_type'] == 2){
							echo '<img src="/v2' . $news['img_path'] . '" alt="" class="inline" />';
						}
							echo( stripslashes($news['entry']) );
							//echo( "<ul class='important_list'></ul>");
					
					//fetch comments
					$fetch2 = mysql_query("SELECT * FROM `comment` WHERE `blogid`=" . $blogid . "");
					if( $fetch2 ){
						$count = 2;
						while($comment = mysql_fetch_array($fetch2)){
							if( $comment['type'] == 2){
								$count = 3;
							}
							echo("<div id='comment-" . $count . "'>");
							echo("<h1>from: " . $comment['user'] . " | " . date('M d, Y g:i a',strtotime($comment['date'])) . "</h1>");
							echo( stripslashes($comment['comment']) );
							echo("</div>");
							if( $count == 2){
								$count = 1;
							}else{
								$count = 2;
							}
						}
					}
				?>
				<br class="clear" />
				<div id="leavecomment">
					<form method="post" action="view_blog.php?bid=<?php echo($blogid); ?>">
							<div class="form_element">
								<p>name</p>
								<input class="text" type="text" maxlength="30" name="name" /><br />
							</div>
							<div class="form_element">
								<p>comment</p>
								<textarea name="comment" rows="5" cols="1"></textarea><br />
							</div>
						<input type="hidden" name="real_check" />
						<input type="submit" name="submit" value="submit comment" onclick="real_check.value='goodboy'" /><br />
					</form>
				</div>
			</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<a href="http://ripeworks.com" target="_blank">ripeworks</a><br />
			<a href="http://del.icio.us/tamagokun" target="_blank">del.icio.us</a><br />
			<a href="http://mikeirl.tumblr.com" target="_blank">tumblr</a><br />
			<br /><br />
			<a href="http://mikekruk.com/rss/feed.xml"><img src="assets/rss.png" alt="rss feed"/></a>
			
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'includes/bottom.php';
?>