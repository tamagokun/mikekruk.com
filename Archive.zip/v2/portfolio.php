<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Mike Kruk - Portfolio</title>
	<link rel="stylesheet" href="master.css" type="text/css" charset="utf-8" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/lavalamp.js"></script>
	<!-- Optional -->
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript" src="js/iepngfix.js"></script>
	<!--[if IE 6]>
		<script type="text/javascript" src="js/jquery.ifixpng.js"></script>
	<![endif]-->
	<script type="text/javascript" src="js/portfolio.js"></script>
</head>
<body>
<?php
	include 'includes/top.php';
?>

<div id="bottom-wrapper">
	<div id="content">
		<div id="maincontent">
			<div class="top"></div>
			<!-- 
				Forgotten Destiny
										-->
			<div class="mid">	
					<img src="assets/portfolio/fd_large.jpg" alt="forgotten destiny" class="photo" />
					<h2>Forgotten Destiny</h2>
					<h3>re-design for homebrew multi-player online game</h3>
					<p>After many attempts to create a great looking web site, and after many mock designs, this design finally came to me, and I am completely satisfied. This was an in-house project done by myself, and will be finished to perfection once the online game goes into public beta.</p>
					<ul>
						<li>XHTML, CSS, JavaScript, PHP, Flash AS3</li>
						<li>use of jQuery to simulate AJAX</li>
						<li>custom ground-up forum section</li>
						<li>ticket system</li>
						<li>complete back-end for game masters</li>
					</ul>
					<p>
						<a href="http://forgottendestiny.net/dev/" target="_blank">view site</a>
					</p>
				</div>
			<!-- 
				Victoria Wedding Chapel
										-->
										<div class="mid" style="display: none;">	
											<img src="assets/portfolio/victoria_large.jpg" alt="Victoria Wedding Chapel" class="photo" />
											<h2>Victoria Wedding Chapel</h2>
											<h3>experience victoria</h3>
											<p>My first client-based web project for a local wedding chapel. This was a re-design project, using most of the original content. Many new features were added including a custom back-end for managing photos and specials. A custom monthly specials service using a WYSIWYG editor. Provided more structure to layout and content for easier usability.</p>
											<ul>
												<li>XHTML, CSS, JavaScript, PHP</li>
												<li>custom back-end</li>
											</ul>
											<p>
												<a href="http://victoriaweddingchapel.com" target="_blank">view site</a>
											</p>
										</div>
										<!-- 
											Blah Blah Worlds
																	-->
										<div class="mid" style="display: none;">	
												<img src="assets/portfolio/fd_large.jpg" alt="Blah Blah Worlds" class="photo" />
												<h2>Blah Blah Worlds 2.0</h2>
												<h3>bringing the world together one blah at a time</h3>
												<p>Originally based off of a small blog project back in 2004, this is the second attempt at creating my complete from-the-ground-up social network service. The site offers many uses of different social media outlets to provide a mash-up or user information. Also to give a hip style to the social media world.</p>
												<ul>
													<li>XHTML, CSS, JavaScript, PHP</li>
													<li>extensive database schema design</li>
													<li>custom profile customization</li>
													<li>custom ground-up forums</li>
													<li>rss aggregator</li>
												</ul>
												<p>
													<a href="#"><del>view site</del></a>
												</p>
											</div>
			<div class="bottom"></div>
		</div>

		<div id="relatedcontent">
			<!-- Sweet JS portfolio viewing thingy! -->
			<ul id="folio">
				<li id="port0"><img src="assets/portfolio/fd.jpg" alt="Forgotten Destiny" /></li>
				<li id="port1"><img src="assets/portfolio/victoria.jpg" alt="Victoria Wedding Chapel" /></li>
				<li id="port2"><img src="assets/portfolio/bbworld.jpg" alt="Blah Blah Worlds" /></li>
			</ul>
			<br class="clear" />
		</div>
		<br class="clear" />
	</div>
</div>
<?php
	include 'includes/bottom.php';
?>