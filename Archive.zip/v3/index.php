<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <title>Mike Kruk</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" href="stylesheets/master.css" type="text/css" media="screen" charset="utf-8">
        <script type="text/javascript" src="javascripts/jquery.js"></script>
		<script src="/facebox/facebox.js" type="text/javascript"></script>
		<script type="text/javascript" src="javascripts/jquery.form.js"></script>
    </head>
    <body>
		<div id="nav">
			<a class="mail" href="contact.php" rel="facebox">Contact Me</a>
        </div>
		<h1><a href="http://mikekruk.com/">Mike Kruk</a></h1>
		<div id="main-content">
			<?php
			
				//lets get all of my tweets :)
				
				$buffer = file_get_contents("http://twitter.com/statuses/user_timeline/tamagokun.xml?count=20");
				
				$posts = new SimpleXMLElement($buffer);
				
				/*$ch = curl_init();
				
				curl_setopt($ch, CURLOPT_URL, '');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_USERPWD, 'Tamagokun:password');
				
				$exec = curl_exec($ch);
				
				*/
				$allowed_hashes = array('#tama','#blog');
				
				foreach($posts as $post){
					
					if( strpos($post->source,"twitpic") > 0 ){
						//we have a photo
						$extract = preg_match("@^(?:http://)?([^ - ]+)@i",$post->text,$match);
						//take the URL out of the post
						$post->text = str_replace($match[0].' - ', '', $post->text);
						//$photo_buffer = file_get_contents($match[0]);
						$imglink = $match[0];
						$imgid = str_replace('http://twitpic.com/','',$match[0] );
						
						$imgtag = '<a href="'.$imglink.'" target="blank"><img src="http://twitpic.com/show/mini/'.$imgid.'" style="border:5px solid white; margin: 3px;" /></a>';
						
						//$imgtag = preg_match("/<img\s+[^>]*id=\"pic\"*[^>]*>/", $photo_buffer, $tag_match);
						//print_r($tag_match);
						
						//$photo = $tag_match[0];
						//$photo = str_replace('style="border:10px solid white;"', '', $tag_match[0]);
						//make sure the SRC is correct
						//if( strpos($tag_match[0], 'src="/') > 0){
						//	$photo = str_replace('src="/', 'src="http://twitpic.com/', $photo);
						//}

					}
					
					//build the post, and throw in the img tag if it should have one
					$the_post = str_replace($hashTag, '', $post->text);
					if( $imgtag){
						$the_post = $imgtag.'<br />'.$the_post;
						$imgtag = null;
					}
					?>
					<div class="twit">
						<div class="tri"></div>
						<div class="content">
							<p><?php echo $the_post; ?></p>
							<p class="comment"><a href="detail.php?bdg=<?php echo $post->id; ?>#disqus_thread">View Comments</a></p>
						</div>
						<div class="bottom"></div>
					</div>
					<?php
				}
			?>
			
		</div>
		<div id="footer">
			<p class="float"><img class="badge" src="images/footer.png" alt="&copy; 2009 Mike Kruk. All Rights Reserved." />
				<span class="current-box">v3</span><a class="version-box" href="/v2/" target="_blank">v2</a><a class="version-box" href="/v1/" target="_blank">v1</a><div class="clear"></div></p>
			
			<p><a href="http://ripeworks.com/" target="_blank"><img border="0" src="http://ripeworks.com/wp-content/themes/ripe_works/images/foot-rw.gif" alt="Ripeworks" /></a></p>
		</div>
		<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
		</script>
		<script type="text/javascript">
		//<![CDATA[
		(function() {
				var links = document.getElementsByTagName('a');
				var query = '?';
				for(var i = 0; i < links.length; i++) {
					if(links[i].href.indexOf('#disqus_thread') >= 0) {
						query += 'url' + i + '=' + encodeURIComponent(links[i].href) + '&';
					}
				}
				document.write('<script charset="utf-8" type="text/javascript" src="http://disqus.com/forums/mikekruk/get_num_replies.js' + query + '"></' + 'script>');
			})();
		//]]>
		</script>
		<script type="text/javascript">
		_uacct = "UA-4214672-1";
		urchinTracker();
		</script>
    </body>
</html>
