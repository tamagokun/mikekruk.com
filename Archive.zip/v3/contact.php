<p id='success' style="display:none;">Your email is sent! Thanks!</p>
<p id='bademail' style="display:none;">Please enter a valid email.</p>
<p id='badserver' style="display:none;">Your email failed. Try again later.</p>
<form id="myForm" action="send_mail.php" method="post">
	<p><label for="nameinput">Name:</label></p>
	<input type="text" id="nameinput" name="name" size='27'/> <br /><br />
	<p><label for="emailinput">Email:</label></p>
	<input type="text" id="emailinput" name="email" size='27'/> <br /><br />
	<p><label for="commentinput">Comments:</label></p>
	<textarea name="comment" id="commentinput" cols='25' rows='4'></textarea> <br /><br />
	<center><input type="submit" id="submitinput" name="submitinput" value="Send it!" /> </center>
</form>
<script type="text/javascript">
		$('#myForm').ajaxForm(function(data) {
			if (data==1){
				$('#success').fadeIn("slow");
				$('#myForm').resetForm();
			}
			else if (data==2){
				$('#badserver').fadeIn("slow");
			}
			else if (data==3)
			{
				$('#bademail').fadeIn("slow");
			}
		});
</script>