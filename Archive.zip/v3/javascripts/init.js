	$(document).ready(function(){
		$('#myForm').ajaxForm(function(data) {
			if (data==1){
				$('#success').fadeIn("slow");
				$('#myForm').resetForm();
			}
			else if (data==2){
				$('#badserver').fadeIn("slow");
			}
			else if (data==3)
			{
				$('#bademail').fadeIn("slow");
			}
		});
	});