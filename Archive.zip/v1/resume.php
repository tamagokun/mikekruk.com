<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a></div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="blog-wrap">
	<p>
	<img src="images/mikebio.jpg" alt="that's me!" style="float:left;padding-right:10px" /><span style="font-size:24px"><span style="color:#fff">Mike</span><span style="color:#C1D4FF">Kruk</span></span>
	<br />
	<span style="color:#ccc">(248) 462-5591<br />
	tamagokun[at]gmail.com<br />
	<br />
	<br />
	<br />
	<br />
	</span>
	
	<span style="font-size:20px">Unique and original Web Developer</span> with much experience in designing solid websites using <span style="font-size:18px">CSS</span> and <span style="font-size:18px">XHTML</span> according to today�s Web Standards. Ability to create original designs using <span style="font-size:18px">Adobe Photoshop</span>, which are brought upon by influences from fashion, music, and photography. Highly skilled in creating and managing <span style="font-size:18px">SQL databases</span>, developing with <span style="font-size:18px">PHP</span>, and using <span style="font-size:18px">JavaScript</span> for creating dynamic websites.<br /><br />

<span style="color:#ccc;font-size:14px">Recent accomplishment</span> Victoria Wedding Chapel<br />
<span style="font-size:12px">The design, layout, and code are entirely my work.<br />
XHTML, CSS, and PHP were used for coding and layout.<br />
All graphics created using Adobe Photoshop or were provided by the company.<br />
<br /></span>
<span style="color:#ccc;font-size:14px">Recent employment</span> Slick & Bubba�s<br />
<span style="font-size:12px">I did the following for still-looking.com using ASP<br />
�	database communication<br />
�	database structure<br />
�	user control panel<br />
�	registration<br />
�	page layout<br />
�	photo management<br />
I provided web marketing and advertisement advice.<br />
I worked as a team player by attending meetings, and communicating to help the business grow.<br />
</span><br />
<br />
<span style="color:#ccc;font-size:14px">Employment History</span><br />
<span style="color:#C1D4FF">Organic Inc.</span> <span style="font-size:9px">10/2007 - present</span><br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DUTIES</span><br />
�	code websites using XHTML, CSS, Javascript, Flash<br />
�	use advanced web management software<br />
�	attend meetings<br />
�	work on projects as a team<br />
<br />
<span style="color:#C1D4FF">Slick & Bubba�s</span> <span style="font-size:9px">12/2005 � 2/2006</span><br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DUTIES</span><br />
�	code websites using ASP, PHP, XHTML, CSS, JavaScript<br />
�	design graphics in Adobe Photoshop and Maya 7.0<br />
�	attend business meetings<br />
�	give input to marketing and advertising strategies<br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">REASON FOR LEAVING</span><br />
�	never received any form or payment<br />
Working here gave me an eye opener to the IT world and showed me that web design is in fact, my true passion.<br />
<br />
<span style="color:#C1D4FF">GUESS?</span> <span style="font-size:9px">10/2005 � 10/2007</span><br />
  &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DUTIES</span><br />
�	handle legal tender<br />
�	team communication<br />
�	loss prevention<br />
�	business management<br />
�	customer service<br />
Working in the fast-paced retail business, I have learned skills such as quick decision making, people skills, and financial responsibilities.<br />
<br />
<span style="color:#C1D4FF">Ben & Jerry�s</span> <span style="font-size:9px">08/2001 � 09/2006</span><br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DUTIES</span><br />
�	manage store<br />
�	handle inventory deliveries<br />
�	help create employee schedule<br />
�	train new employees<br />
�	count and keep record of store income<br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">REASON FOR LEAVING</span><br />
�	new owner caused many internal problems with running the business<br />
�	hourly wage not meeting up to my needs<br />
For being my first job, and working here for 5 years, it has taught a great deal about running a business as well as being loyal to that business and handling tough situations.<br />
<br />
<span style="color:#ccc;font-size:14px">Education History</span><br />
<span style="color:#C1D4FF">Oakland Community College</span> <span style="font-size:9px">2005 � present</span><br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DEGREE</span><br />
�	actively attaining my associate�s degree in Computer Science<br />
Focused on the aspects of web development<br />
After receiving my associate�s degree, I plan to transfer to a University to achieve my bachelor�s degree.<br />
<br />
<span style="color:#C1D4FF">Tokai University</span> <span style="font-size:9px">09/2004 � 09/2005</span><br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DEGREE</span><br />
�	received certificate for Japanese Language Proficiency<br />
A one year long course<br />
Living in Japan on my own, and being engulfed by a new culture and language completely opened my senses to the world, and has ultimately helped me become a better person, and gave me the confidence to reach any goal.<br />
<br />
<span style="color:#C1D4FF">Clarkston High School</span> <span style="font-size:9px">08/2001 � 05/2004</span><br />
   &nbsp;&nbsp;<span style="color:#ccc;font-size:10px">DIPLOMA</span><br />
�	class of 2004<br />
�	graduated with honors in the National Japanese Honor Society<br />
I had the privilege to study many different IT courses such as Visual Basic, C++, A+ Certification, and Network+ Certification.<br />
<br />
<span style="color:#ccc;font-size:14px">Portfolio</span><br />
mikekruk.com<br />
Here you can find all my web design projects, an online resume, and my contact information.<br />
<br />
<span style="color:#ccc;font-size:14px">Software Proficiency</span><br />
<span style="font-size:16px;">Microsoft Windows</span><br />
<span style="font-size:14px;">Apple OS X</span><br />
<span style="font-size:12px;">Linux</span><br />
<span style="font-size:16px;">Adobe Dreamweaver CS3</span><br />
<span style="font-size:14px;">Adobe Flash CS3</span><br />
Adobe Photoshop<br />
Adobe Image Ready<br />
<span style="font-size:12px;">Adobe Illustrator</span><br />
Microsoft SQL Server<br />
<span style="font-size:16px;">Microsoft Visual Basic</span><br />
Microsoft Word<br />
Microsoft Excel<br />
Microsoft PowerPoint<br />
Microsoft Visio<br />

	</p>
	</div>
	</div>
	
</div>
</div>
</body>
</html>