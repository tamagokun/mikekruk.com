<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="col">
	<h1>news & updates</h1>
	<ul>
	<?php
		//fetch recent news
		$fetch = mysql_query("SELECT * FROM `fd_news` ORDER BY `id` DESC");
		if( $fetch ){
			$count = 1;
			while($news = mysql_fetch_array($fetch)){
			echo("<li><a href='fd_view_news.php?bid=" . $news['id'] . "'><span class='rec-date'>" . date('M d, Y',strtotime($news['date'])) . "&nbsp;</span>&nbsp;" . stripslashes($news['title']) . "</a>");
			if( $count == 1){
				echo("<br /><blockquote>" . substr_replace(stripslashes($news['entry']), '...', 50) . "</blockquote></li>");
			}else{
				echo("</li>");
			}
			$count++;
			}
		}
	?>	
	</ul>
	</div>
	
	<div class="col">
	<h1>about</h1>
		<ul>
		<li><a href="#"><img src="images/fd/book.png" border="0" align="top" />&nbsp;story</a></li>
		<li><a href="#"><img src="images/fd/user.png" border="0" align="top" />&nbsp;characters</a></li>
		<li><a href="#"><img src="images/fd/controller.png" border="0" align="top" />&nbsp;gameplay</a></li>
		<li><a href="#"><img src="images/fd/brick.png" border="0" align="top" />&nbsp;in the making</a></li>
		</ul>
	</div>
	<div class="col">
	<h1>screenies</h1>
	<ul class="ss">
		<?php
		//fetch screenshots
		$fetch = mysql_query("SELECT * FROM `fd_screen` ORDER BY `date` DESC");
		if( $fetch ){
			while($screens = mysql_fetch_array($fetch)){
				echo("<li><a href='fd_view_ss.php?sid=" . $screens['id'] . "'><img src='screens/" . $screens['file'] . "' width='100' /></a></li>");
			}
		}
	?>	
	</ul>
	</div>
	</div>
	
</div>
</div>
</body>
</html>