	<div id="menu-wrap">
		<ul>
		<li><a href="index.php">I. Home</a></li>
		<li><a href="portfolio.php">II. Portfolio</a></li>
		<li><a href="blog.php">III. Blog</a></li>
		<li><a href="photos.php">IV. Photos</li>
		<li><a href="resume.php">V. Resume</a></li>
		<li><a href="contact.php">VI. Contact</a></li>
		</ul>
	</div>
	<?php
		mysql_connect('127.0.0.1','root','bananaphone');
		mysql_select_db('mkruk_archive');
	?>
	<div id="title-wrap">
		<h1>Prodigious</h1>
		<h2>happens here</h2>
		<p>Welcome to the home of tamago.designs, and creator, mike kruk. Enjoy your stay.</p>
	</div>
	<div id="feature-wrap">
		<a href="http://forgottendestiny.net/test/" rel="external" ><img src="images/THE AD.gif" border="0" /></a>
	</div>
	<script language="javascript">
	function externalLinks() {
	 if (!document.getElementsByTagName) return;
	 var anchors = document.getElementsByTagName("a");
	 for (var i=0; i<anchors.length; i++) {
	   var anchor = anchors[i];
	   if (anchor.getAttribute("href") &&
		   anchor.getAttribute("rel") == "external")
		 anchor.target = "_blank";
	 }
	}
	window.onload = externalLinks;
	</script>