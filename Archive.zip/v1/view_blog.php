<?php
ob_start();
include 'admin/func.php';

	if(isset($_GET['bid'])){
		if(is_numeric($_GET['bid'])){
			$blogid = $_GET['bid'];
		}else{
			die("ID is not a number. What are you doing?!");
		}
	}else{
		die("ID is missing. What are you doing?!");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href=#><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="blog-wrap">
		<?php
			//handle comment posting
			if(isset($_POST['submit'])){
				if($_POST['real_check'] == 'goodboy'){
					if(!empty($_POST['name']) && !empty($_POST['comment'])){
						//do the post
						$name = addslashes($_POST['name']);
						$comment = addslashes($_POST['comment']);
						//handle logged in status for comment type
						if(isset($_COOKIE['port_id']) && isset($_COOKIE['port_pass'])){
							$my_type = 2;
						}else{
							$my_type = 1;
						}
						$query = mysql_query("INSERT INTO `comment` SET `blogid`=" . $blogid . ", `date`=now(), `user`='" . $name . "', `comment`='" . $comment . "', `type`=" . $my_type . "");
					}
				}
			}
			
			//fetch blog
			$fetch = mysql_query("SELECT * FROM `news` WHERE `id`=" . $blogid . "");
			if( $fetch ){
				$blog = mysql_fetch_array($fetch);
				echo("<div id='date'><strong>" . date('M d',strtotime($blog['date'])) . "</strong><br />" . date('g:i a',strtotime($blog['date'])) . "<br />");
				//fetch comment count
				$subfetch = mysql_num_rows(mysql_query("SELECT `id` FROM `comment` WHERE `blogid`=" . $blogid . ""));
				echo("<br /><br /><a href='#'>" . $subfetch . " comments</a>");
				?>
				<br />
				<br />
				<a href="blog.php#<?php echo($blogid); ?>">back to blogs</a>
				</div>
				<div id="blog">
				<?php
				echo("<h1>" . stripslashes($blog['title']) . "</h1>");
				if($blog['img_type'] == 1){
					echo '<p><img src="' . $blog['img_path'] . '" alt="" /></p>';
				}
				if($blog['img_type'] == 2){
					echo '<img src="' . $blog['img_path'] . '" alt="" class="inline" />';
				}
				echo( stripslashes($blog['entry']) );
				?>
				</div>
				<?php
			}
	
			//fetch comments
			$fetch2 = mysql_query("SELECT * FROM `comment` WHERE `blogid`=" . $blogid . "");
			if( $fetch2 ){
				$count = 2;
				while($comment = mysql_fetch_array($fetch2)){
					if( $comment['type'] == 2){
						$count = 3;
					}
					echo("<div id='comment-" . $count . "'>");
					echo("<h1>from: " . $comment['user'] . " | " . date('M d, Y g:i a',strtotime($comment['date'])) . "</h1>");
					echo( stripslashes($comment['comment']) );
					echo("</div>");
					if( $count == 2){
						$count = 1;
					}else{
						$count = 2;
					}
				}
			}	
		?>
		<p style="clear: both;">
		Leave a Comment<br />
		<form method="post" action="view_blog.php?bid=<?php echo($blogid); ?>">
			<table>
			<tr><td><span class="formi">name:&nbsp;</span></td><td><input type="text" size="30" maxlength="30" name="name" /><span class="formi">&nbsp;(required)</span></td></tr>
			<tr><td></td><td><textarea name="comment" rows="4" cols="30" wrap="soft"></textarea></td></tr>
			<input type="hidden" name="real_check" />
			<tr><td></td><td><input type="submit" name="submit" value="submit comment" onClick="real_check.value='goodboy'" /></td></tr>
			</table>
		</form>
		</p>
	</div>
	</div>

</div>
</div>
</body>
</html>