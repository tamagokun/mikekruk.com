<?php
ob_start();
include 'admin/func.php';

	if(isset($_GET['bid'])){
		if(is_numeric($_GET['bid'])){
			$blogid = $_GET['bid'];
		}else{
			die("ID is not a number. What are you doing?!");
		}
	}else{
		die("ID is missing. What are you doing?!");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href=#><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="blog-wrap">
		<?php
			
			//fetch blog
			$fetch = mysql_query("SELECT * FROM `fd_news` WHERE `id`=" . $blogid . "");
			if( $fetch ){
				$blog = mysql_fetch_array($fetch);
				echo("<div id='date'><strong>" . date('M d',strtotime($blog['date'])) . "</strong><br />" . date('g:i a',strtotime($blog['date'])) . "<br />");
				?>
				<br />
				<a href="blog.php#<?php echo($blogid); ?>">view all news</a><br /><br />
				<a href="fd.php">go back</a>
				</div>
				<div id="blog">
				<?php
				echo("<h1>" . stripslashes($blog['title']) . "</h1>");
				echo( stripslashes($blog['entry']) );
				?>
				</div>
				<?php
			}
	
		?>
		<p style="clear: both"></p>
	</div>
	</div>

</div>
</div>
</body>
</html>