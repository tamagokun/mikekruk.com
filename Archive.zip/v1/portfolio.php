<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="col">
	<h1>active projects</h1>
	<p>
		<a href="http://68.60.123.48/" rel="external">blahblah worlds v2.0<br />
		<img src="images/port/bb2.jpg" border="0" alt="blahblah worlds v2.0" /></a><br />
		<blockquote>My latest re-design to an internet community idea started in 2004. [under construction]</blockquote>
	</p>
	<p>
		<a href="http://68.60.123.48/rhr/" rel="external">rats have rights<br />
		<img src="images/port/rhr.jpg" border="0" alt="rats have rights" /></a><br />
		<blockquote>A website made for my band, rats have rights. [under construction]</blockquote>
	</p>
	</div>
	
	<div class="col">
	<h1>web portfolio</h1>
	<p>
		<a href="http://68.60.123.48/battle/" rel="external">Multiplayer Isometric Example<br />
		<img src="images/port/3diso.jpg" border="0" alt="3d isometric game" /></a><br />
		<blockquote>The beginings of a multiplayer online flash developed game using ActionScript. The socket server was coded using PHP.</blockquote>
	</p>
	<p>
		<a href="http://victoriaweddingchapel.com/" rel="external">Victoria Wedding Chapel<br />
		<img src="images/port/victoria.jpg" border="0" alt="victoria wedding chapel" /></a><br />
		<blockquote>My first paid web project. Design & code was done by me.</blockquote>
	</p>
	</div>
	<div class="col">
	<h1>personal / old</h1>
	<p>
		<a href="#">blahblah Worlds v1.5 <strong>[inactive]</strong><br />
		<img src="images/port/bb12.jpg" border="0" alt="blahblah worlds v1.5" /></a><br />
	</p>
	<p>
		<a href="http://68.60.123.48/lifestyle/" rel="external">blahblah Lifestyle<br />
		<img src="images/port/bblife.jpg" border="0" alt="blahblah lifestyle" /></a><br />
		<blockquote>My 2nd blog site that gave birth to blah blah worlds.</blockquote>
	</p>
	<p>
		<a href="http://68.60.123.48/lifestyle/oldness/blahblahv1/" rel="external">BlahBlah<br />
		<img src="images/port/bb1.jpg" border="0" alt="blahBlah" /></a><br />
		<blockquote>My 1st fully operational blog/photo/forum website.</blockquote>
	</p>
	</div>
	</div>
	
</div>
</div>
</body>
</html>