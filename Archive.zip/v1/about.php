<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a></div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="col">
	<h1>biography</h1>
	<p>
	<img src="images/mikebio.jpg" alt="that's me!" style="float: right;" />&nbsp;&nbsp;&nbsp;I was born and raised in Michigan, and currently live in Clarkston. I am 20 years old, attending <a href="http://oaklandcc.edu" rel="external">OCC</a> for web design, and I work at <a href="http://gbyguess.com" rel="external">GUESS?</a>. For free time, I write music for my band (rats have rights) and I also have a side business (you guessed it) make websites. Hopefully it will one day brach off into something bigger.
	</p>
	<p>&nbsp;&nbsp;&nbsp;As for other things, I have a lovely girlfriend and enjoy eating lots of food. Japanese is probably the best and most interesting language ever, and you all should learn it.</p>
	</div>
	
	<div class="col">
	<h1>my education</h1>
	<p>
		Clarkston High School<br />
	  <blockquote>
			2001-2004<br />
			general education<br />
			japanese<br />
			A+ certification<br />
			high school diploma<br />
	  </blockquote>
	</p>
	<p>
		Tokai University<br />
	  <blockquote>
			2004-2005<br />
			japanese<br />
			Japanese Language Certificate<br />
	  </blockquote>
	</p>
	<p>
		Oakland Community College<br />
	  <blockquote>
			2006-present<br />
			attending for associates degree in CS (web design)<br />
	  </blockquote>
	</p>
	</div>
	<div class="col">
	<h1>skills / abilities</h1>
	<p>
	  <blockquote>
			xhtml<br />
			css<br />
			php<br />
			javascript<br />
			sql<br />
			visual basic<br />
			adobe photoshop<br />
			adobe image ready<br />
			dreamweaver<br />
			excel<br />
	  </blockquote>
	</p>
	<h1>contact me</h1>
	<p>
		You can reach me by <a href="mailto:tamagokun@gmail.com" title="tamagokun@gmail.com">e-mail</a>, or simply fill out the form below.<br />
		<?php
			if(isset($_POST['submit'])){
				//send me an email!
				mail('tamagokun@gmail.com','MIKEKRUK.com contact message ' . $_POST['name'],$_POST['email'] . '\n' . $_POST['comment']);
				//tell user that message was sent
				?>
				<span class="formi">message was sent to mike.</span>
				<?php
			}else{
				//display form
		?>
	  <form method="post" action="about.php">
		<table>
		<tr><td><span class="formi">name:&nbsp;</span></td><td><input type="text" size="20" name="name" /></td></tr>
		<tr><td><span class="formi">e-mail:&nbsp;</span></td><td><input type="text" size="20" name="email" /></td></tr>
		<tr><td><span class="formi">comment:&nbsp;</span></td><td><textarea name="comment" rows="5" cols="25"></textarea></td></tr>
		<tr><td></td><td><input type="submit" value="send" name="submit" />&nbsp;<input type="reset" value="clear" /></td></tr>
		</table>
	  </form>
		<?php
			}
		?>
	</p>
	</div>
	</div>
	
</div>
</div>
</body>
</html>