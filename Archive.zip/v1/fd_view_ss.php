<?php
	
	if(isset($_GET['sid'])){
		if(is_numeric($_GET['sid'])){
			$id = $_GET['sid'];
		}else{
			die("Screen ID is not a number! What are you doing?!");
		}
	}else{
		$id = 1;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<?php 
	//get screenshot data
	$query3 = mysql_query("SELECT * FROM `fd_screen` WHERE `id`=" . $id . "");
	if( $query3 ){
		$this_photo = mysql_fetch_array($query3);
	}
	
?>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="col">
	<h1>screenshots</h1>
	<ul>
		<?php
		//fetch the rest of the screens
		$query = mysql_query("SELECT * FROM `fd_screen` ORDER BY `date` DESC");
		if( $query ) {
			while($screens = mysql_fetch_array($query)){
				//display stuff
				if($screens['id'] == $id){
				?>
				<li class="album_on"><a href="fd_view_ss.php?sid=<?php echo($screens['id']); ?>"><?php echo($screens['caption']); ?></a></li>
				<?php
				}else{
				?>
				<li><a href="fd_view_ss.php?sid=<?php echo($screens['id']); ?>"><?php echo($screens['caption']); ?></a></li>
				<?php
				}
			}
		}
		?>
	</ul>
	<a class="fd" href="fd.php">go back</a>
	
	</div>
	<div id="photo">
		<img class="photo" src="screens/<?php echo($this_photo['file']); ?>" /><br />
		<span class="num"><?php echo( date('M d, Y',strtotime($this_photo['date'])) ); ?></span> | <?php echo(stripslashes($this_photo['caption'])); ?><br />
	</div>
	
	</div>
	
</div>
</div>
</body>
</html>