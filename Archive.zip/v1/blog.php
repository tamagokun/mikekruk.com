<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href=#><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<?php
		//get blogs
		$fetch = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC");
		if( $fetch ){
			while($news = mysql_fetch_array($fetch)){
				?>
				<div class="blog-wrap" id="<?php echo($news['id']); ?>">
					<div id="date"><strong><?php echo(date('M d',strtotime($news['date']))); ?></strong><br /><?php echo(date('g:i a',strtotime($news['date']))); ?><br />
					<?php
					//fetch comment count
					$subfetch = mysql_num_rows(mysql_query("SELECT `id` FROM `comment` WHERE `blogid`=" . $news['id'] . ""));
					?>
					<br /><br /><a href="view_blog.php?bid=<?php echo($news['id']); ?>"><? echo($subfetch); ?> comments</a>					</div>
				<div id="blog">
				<h1><a href="view_blog.php?bid=<?php echo($news['id']); ?>"><?php echo(stripslashes($news['title'])); ?></a></h1>
                
				<?php 
				if($news['img_type'] == 1){
					echo '<p><img src="' . $news['img_path'] . '" alt="" /></p>';
				}
				if($news['img_type'] == 2){
					echo '<img src="' . $news['img_path'] . '" alt="" class="inline" />';
				}
				echo(stripslashes($news['entry'])); ?></div>
				</div>
				<br />
				<?php
			 }
		}
	?>
	</div>

</div>
</div>
</body>
</html>