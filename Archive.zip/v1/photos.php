
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php
	if(isset($_GET['al'])){
		if(is_numeric($_GET['al'])){
			$album = $_GET['al'];
		}else{
			die("Album ID is not a number! What are you doing?!");
		}
	}else{
		$album = 1;
	}
	
	if(isset($_GET['pid'])){
		if(is_numeric($_GET['pid'])){
			$id = $_GET['pid'];
		}else{
			die("Photo ID is not a number! What are you doing?!");
		}
	}else{
		$id = 0;
	}	
	
?>

</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="col">
	<h1>photo albums</h1>
	<ul>
		<?php
		//fetch the photo albums
		$query = mysql_query("SELECT * FROM `album` ORDER BY `id` DESC");
		if( $query ) {
			while($albums = mysql_fetch_array($query)){
				//display stuff
				if($albums['id'] == $album){
				?>
				<li class="album_on"><a href="photos.php?al=<?php echo($albums['id']); ?>&pid=0"><?php echo($albums['name']); ?></a></li>
				<?php
				}else{
				?>
				<li><a href="photos.php?al=<?php echo($albums['id']); ?>&pid=0"><?php echo($albums['name']); ?></a></li>
				<?php
				}
			}
		}
		?>
	</ul>
	</div>
	<div id="photo">
	<?php
		//get album data
		$query2 = mysql_query("SELECT * FROM `album` WHERE `id`=" . $album . "");
		if( $query2 ){
			$this_album = mysql_fetch_array($query2);
		}
		//grab flickr album
		$get_obg = file_get_contents($this_album['feed']);
		$album_obj = unserialize($get_obg);
		
		$max = count($album_obj['items']);
		
		echo '<img class="photo" src="'. $album_obj['items'][$id]['l_url'] .'" />';
		echo '<span class="num">' . ($id + 1) . '</span> of <span class="num">' . $max . '</span>';
		echo ' | '. $album_obj['items'][$id]['description_raw'] . '<br />';
	
		if($id > 0){
			//show previous
			echo '<a href="photos.php?al=' . $album . '&pid=' . ($id - 1) . '">';
			echo '<img border="0" src="images/photo-prev.gif" alt="previous" /></a>&nbsp;&nbsp;';
		}
		if($id + 1 < $max){
			//show next
			echo '<a href="photos.php?al=' . $album . '&pid=' . ($id + 1) . '">';
			echo '<img border="0" src="images/photo-next.gif" alt="next" /></a>';
		}
		
	?>
	</div>
	
	</div>
	
</div>
</div>
</body>
</html>