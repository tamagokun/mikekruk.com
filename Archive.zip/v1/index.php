<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tamago.designs - Brought to you by Mike Kruk</title>
<link rel="stylesheet" type="text/css"  href="css.css" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Prodigious happens here. Welcome to the home of tamago.designs, and creator, mike kruk. Read blogs, view my personal photos, and check out my web portfolio.">
<meta name="keywords" content="tamago,tamago.designs,tamago-designs,blog,mike,kruk,mike kruk,web,internet,web design,portfolio,html,xhtml,css,php,java,javascript" />
<meta name="verify-v1" content="h2lSl5rXAwrhCv1s3HhPLSQCK7BnmRCg5QsClJeq/6A=" />
<!-- compliance patch for microsoft browsers -->
   <!--[if lt IE 7]><script src="ie7/ie7-standard-p.js" type="text/javascript"></script><![endif]-->
</head>
<body>
<div id="wrapper">
<div id="banner">
<a href="admin/"><img src="images/banner.gif" alt="tamago.designs" border="0" /></a>
</div>
<div id="top">
	<div id="top-wrap">
	<?php include 'menu.php'; ?>
	</div>
</div>
<div id="bottom">
	<div id="bottom-wrap">
	<div class="col">
	<h1>music</h1>
	<p>
		<?php include 'bb.htm'; ?>
	</p>
	</div>
	
	<div class="col">
	<h1>recent</h1>
	<ul>
	<?php
		//fetch recent news
		$fetch = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC");
		if( $fetch ){
			$count = 1;
			while($news = mysql_fetch_array($fetch)){
			echo("<li><a href='view_blog.php?bid=" . $news['id'] . "'><span class='rec-date'>" . date('M d, Y',strtotime($news['date'])) . "&nbsp;</span>&nbsp;" . stripslashes($news['title']) . "</a>");
			if( $count == 1){
				echo("<br /><blockquote>" . substr_replace(stripslashes($news['entry']), '...', 50) . "</blockquote></li>");
			}else{
				echo("</li>");
			}
			$count++;
			}
		}
	?>
	</ul>
	
	</div>
	<div class="col">
	<h1>my linkage</h1>
	<p>
		<a href="http://forgottendestiny.net" rel="external">forgotten destiny</a><br />
		<a href="http://www.myspace.com/mikeirl" rel="external">myspace</a><br />
		<a href="http://www.purevolume.com/ratshaverights" rel="external">purevolume</a><br />
		<a href="http://jp.cyworld.com/tamagokun" rel="external">cyworld [jpn]</a><br />
		<a href="http://www.sitepoint.com" rel="external">sitepoint</a><br />
		<a href="http://www.alistapart.com/" rel="external">a list apart</a><br />
		<a href="http://www.ndesign-studio.com/" rel="external">n.design-studio</a><br />
		<a href="http://www.stepmania.com" rel="external">stepmania</a><br />
	</p>
	</div>
	</div>
	
</div>
</div>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-4214672-1";
urchinTracker();
</script>
</body>
</html>